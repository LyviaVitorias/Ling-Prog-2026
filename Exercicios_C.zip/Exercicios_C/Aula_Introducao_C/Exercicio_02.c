#include <stdio.h>
#include <stdlib.h>

/* Aula Introducao a Linguagem C - Exercicio 2
   Faça um programa que calcule a área de um triângulo retângulo, dados os
   valores de sua base e altura. */

int main(int argc, char *argv[]) {
	float base, altura, area;

	printf("Digite a base: ");
	scanf("%f", &base);
	printf("Digite a altura: ");
	scanf("%f", &altura);

	area = (base * altura) / 2;

	printf("Area = %.2f\n", area);

	return 0;
}
