#include <stdio.h>
#include <stdlib.h>

/* Aula Introducao a Linguagem C - Exercicio 4
   Faça um programa que receba o raio de um círculo, calcule e mostre sua
   área. (Área = π * R2 ) */

int main(int argc, char *argv[]) {
	float raio, area, pi = 3.14159;

	printf("Digite o raio: ");
	scanf("%f", &raio);

	area = pi * raio * raio;

	printf("Area = %.2f\n", area);

	return 0;
}
