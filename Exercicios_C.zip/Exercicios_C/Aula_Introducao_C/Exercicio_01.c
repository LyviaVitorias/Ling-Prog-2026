#include <stdio.h>
#include <stdlib.h>

/* Aula Introducao a Linguagem C - Exercicio 1
   Faça um programa que receba dois número, efetue a soma e mostre o
   resultado na tela. */

int main(int argc, char *argv[]) {
	float a, b, soma;

	printf("Digite o primeiro numero: ");
	scanf("%f", &a);
	printf("Digite o segundo numero: ");
	scanf("%f", &b);

	soma = a + b;

	printf("Soma = %.2f\n", soma);

	return 0;
}
