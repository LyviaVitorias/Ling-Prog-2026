#include <stdio.h>
#include <stdlib.h>

/* Aula Introducao a Linguagem C - Exercicio 3
   Faça um programa que calcule a média aritmética entre três valores
   informados. Mostre a média na tela. */

int main(int argc, char *argv[]) {
	float v1, v2, v3, media;

	printf("Digite tres valores: ");
	scanf("%f %f %f", &v1, &v2, &v3);

	media = (v1 + v2 + v3) / 3;

	printf("Media = %.2f\n", media);

	return 0;
}
