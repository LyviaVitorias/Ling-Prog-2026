#include <stdio.h>
#include <stdlib.h>

/* Simulado - Exercicio 1
   Faça um programa que leia 4 valores numéricos naturais do teclado, em
   ordem A, B, C, D. e que realize a permutação entre estes respectivos
   valores para a ordem C, A, D, B e apresente na tela. */

int main(int argc, char *argv[]) {
	int a, b, c, d, aux;

	printf("Digite A, B, C e D: ");
	scanf("%d %d %d %d", &a, &b, &c, &d);

	// aux guarda o valor de A para ele nao se perder nas trocas
	aux = a;
	a = c;     // A recebe C
	c = d;     // C recebe D
	d = b;     // D recebe B
	b = aux;   // B recebe o A antigo

	printf("Nova ordem: %d %d %d %d\n", a, b, c, d);

	return 0;
}
