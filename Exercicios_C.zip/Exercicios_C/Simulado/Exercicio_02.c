#include <stdio.h>
#include <stdlib.h>

/* Simulado - Exercicio 2
   No mercado financeiro, o indicador P/VP (Preço sobre Valor Patrimonial) é
   utilizado por investidores para analisar se o preço de uma ação está
   condizente com o valor patrimonial real da empresa. O Valor Patrimonial
   por Ação (VPA) é calculado dividindo o valor patrimonial total da empresa
   pela quantidade total de ações disponíveis (VPA = Valor da Empresa /
   Quantidade de Ações). Já o indicador P/VP é obtido dividindo o Preço por
   Ação pelo VPA (P/VP = Preço por Ação / VPA).
   Faça um programa em linguagem C que leia:
   - O valor patrimonial da empresa (em R$);
   - A quantidade de ações disponíveis;
   - O preço atual da ação (em R$).
   O programa deve calcular o VPA e o indicador P/VP, e exibir na tela a
   classificação da ação para compra de acordo com a tabela abaixo:
   Faixa do P/VP              Classificação
   P/VP < 0,0                 Péssima
   0,0 ≤ P/VP < 0,8           Ótima
   0,8 ≤ P/VP ≤ 1,2           Indiferente
   1,2 < P/VP ≤ 2,0           Boa
   P/VP > 2,0                 Ruim */

int main(int argc, char *argv[]) {
	double valor_empresa, quantidade, preco, vpa, pvp;

	printf("Digite o valor patrimonial da empresa: R$ ");
	scanf("%lf", &valor_empresa);
	printf("Digite a quantidade de acoes: ");
	scanf("%lf", &quantidade);
	printf("Digite o preco atual da acao: R$ ");
	scanf("%lf", &preco);

	// evita divisao por zero
	if (quantidade <= 0 || valor_empresa == 0) {
		printf("Valores invalidos para o calculo.\n");
		return 0;
	}

	vpa = valor_empresa / quantidade;
	pvp = preco / vpa;

	printf("VPA: R$ %.2lf\n", vpa);
	printf("P/VP: %.2lf\n", pvp);

	if (pvp < 0.0) {
		printf("Classificacao: Pessima\n");
	} else if (pvp < 0.8) {
		printf("Classificacao: Otima\n");
	} else if (pvp <= 1.2) {
		printf("Classificacao: Indiferente\n");
	} else if (pvp <= 2.0) {
		printf("Classificacao: Boa\n");
	} else {
		printf("Classificacao: Ruim\n");
	}

	return 0;
}
