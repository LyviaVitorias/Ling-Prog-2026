#include <stdio.h>
#include <stdlib.h>

/* Aula Lacos - Exercicio 2
   Faça um programa que recaba um nuumero n e realize a soma dos n primeiros
   termos da sequência definda como:
   [S = 1/2; 1/4; 1/8 1/16... N] */

int main(int argc, char *argv[]) {
	int n, i;
	float termo = 1, soma = 0;

	printf("Digite a quantidade de termos n: ");
	scanf("%d", &n);

	// cada termo e a metade do anterior: 1/2, 1/4, 1/8 ...
	for (i = 1; i <= n; i++) {
		termo = termo / 2;
		soma = soma + termo;
		printf("Termo %d: %f\n", i, termo);
	}

	printf("Soma dos %d termos: %f\n", n, soma);

	return 0;
}
