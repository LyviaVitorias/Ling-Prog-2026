#include <stdio.h>
#include <stdlib.h>

/* Aula Lacos - Exercicio 3
   Crie um programa qe exiba na tela, o trîangulo de pascal. */

#define tam 15

int main(int argc, char *argv[]) {
	int pascal[tam][tam];
	int linhas, i, j;

	printf("Quantas linhas do triangulo (1 a %d)? ", tam);
	scanf("%d", &linhas);

	if (linhas < 1 || linhas > tam) {
		printf("Quantidade invalida!\n");
		return 0;
	}

	/* Regra do triangulo de Pascal:
	   - o primeiro e o ultimo numero de cada linha valem 1;
	   - os outros sao a soma dos dois numeros logo acima. */
	for (i = 0; i < linhas; i++) {
		for (j = 0; j <= i; j++) {
			if (j == 0 || j == i) {
				pascal[i][j] = 1;
			} else {
				pascal[i][j] = pascal[i - 1][j - 1] + pascal[i - 1][j];
			}
			printf("%d ", pascal[i][j]);
		}
		printf("\n");
	}

	return 0;
}
