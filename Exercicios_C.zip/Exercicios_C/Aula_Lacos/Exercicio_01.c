#include <stdio.h>
#include <stdlib.h>

/* Aula Lacos - Exercicio 1
   Elabore um programa que permita a entrada de 3 valores. E conte do
   primeiro valor inserido, até o segundo valor, com o passo da contagem
   dado pelo terceiro valor
   ex: 1,8,2 >> contar de 1 a 8, com passo 2 = 3,5,7.

   Obs: seguindo o exemplo, a contagem mostra os valores depois do primeiro
   (1 + 2 = 3, depois 5, depois 7). */

int main(int argc, char *argv[]) {
	int inicio, fim, passo, i;

	printf("Digite o primeiro valor: ");
	scanf("%d", &inicio);
	printf("Digite o segundo valor: ");
	scanf("%d", &fim);
	printf("Digite o passo: ");
	scanf("%d", &passo);

	if (passo <= 0) {
		printf("O passo deve ser maior que zero.\n");
		return 0;
	}

	for (i = inicio + passo; i <= fim; i = i + passo) {
		printf("%d ", i);
	}
	printf("\n");

	return 0;
}
