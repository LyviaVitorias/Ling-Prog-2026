#include <stdio.h>
#include <stdlib.h>

/* Aula Condicional Multipla - Exercicio 2
   Implementar novamente a lista de exercícios 2, aplicando as estruturas
   condicionais e de seleção aos exercícios, quando for possível e
   necessário, e criando um menu para a seleção de qual exercícios será
   executado. */

int main(int argc, char *argv[]) {
	int opcao;

	do {
		printf("\n===== LISTA 02 - MENU =====\n");
		printf("1 - Ano de nascimento\n");
		printf("2 - km/h para m/s\n");
		printf("3 - Reais para dolares\n");
		printf("4 - Celsius para Fahrenheit\n");
		printf("5 - Graus para radianos\n");
		printf("6 - Antecessor e sucessor\n");
		printf("7 - Premio dos ganhadores\n");
		printf("8 - Segundos para h:m:s\n");
		printf("9 - Litros de combustivel\n");
		printf("10 - Maior de tres valores\n");
		printf("0 - Sair\n");
		printf("Escolha: ");
		scanf("%d", &opcao);

		switch (opcao) {
			case 1: {
				int idade, ano;
				printf("Digite a idade e o ano atual: ");
				scanf("%d %d", &idade, &ano);
				if (idade < 0 || idade > ano) {
					printf("Dados invalidos!\n");
				} else {
					printf("Ano de nascimento: %d\n", ano - idade);
				}
				break;
			}
			case 2: {
				float k;
				printf("Digite a velocidade em km/h: ");
				scanf("%f", &k);
				printf("%.2f m/s\n", k / 3.6);
				break;
			}
			case 3: {
				float reais, cotacao;
				printf("Digite o valor em reais e a cotacao do dolar: ");
				scanf("%f %f", &reais, &cotacao);
				if (cotacao <= 0) {
					printf("A cotacao deve ser maior que zero.\n");
				} else {
					printf("US$ %.2f\n", reais / cotacao);
				}
				break;
			}
			case 4: {
				float c;
				printf("Digite a temperatura em Celsius: ");
				scanf("%f", &c);
				printf("%.2f F\n", c * (9.0 / 5.0) + 32.0);
				break;
			}
			case 5: {
				float g, p = 3.141592;
				printf("Digite o angulo em graus: ");
				scanf("%f", &g);
				printf("%.4f radianos\n", g * p / 180);
				break;
			}
			case 6: {
				int num;
				printf("Digite um numero inteiro: ");
				scanf("%d", &num);
				printf("Antecessor: %d\nSucessor: %d\n", num - 1, num + 1);
				break;
			}
			case 7: {
				float total = 780000.00, primeiro, segundo;
				primeiro = total * 0.46;
				segundo = total * 0.32;
				printf("Primeiro: R$ %.2f\n", primeiro);
				printf("Segundo: R$ %.2f\n", segundo);
				printf("Terceiro: R$ %.2f\n", total - primeiro - segundo);
				break;
			}
			case 8: {
				int tempo;
				printf("Digite o tempo em segundos: ");
				scanf("%d", &tempo);
				if (tempo < 0) {
					printf("Tempo invalido!\n");
				} else {
					printf("%d:%d:%d\n", tempo / 3600, (tempo % 3600) / 60, tempo % 60);
				}
				break;
			}
			case 9: {
				int tempo, velocidade;
				printf("Digite o tempo (horas) e a velocidade media (km/h): ");
				scanf("%d %d", &tempo, &velocidade);
				printf("%.3f\n", (tempo * velocidade) / 12.0);
				break;
			}
			case 10: {
				int a, b, c, maior;
				printf("Digite tres valores: ");
				scanf("%d %d %d", &a, &b, &c);
				// agora com condicionais, sem precisar da formula
				maior = a;
				if (b > maior) maior = b;
				if (c > maior) maior = c;
				printf("%d eh o maior\n", maior);
				break;
			}
			case 0:
				printf("Saindo...\n");
				break;
			default:
				printf("Opcao invalida!\n");
		}
	} while (opcao != 0);

	return 0;
}
