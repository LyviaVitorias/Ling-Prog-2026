#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Aula Condicional Multipla - Exercicio 1
   Implementar novamente a lista de exercícios 1, aplicando as estruturas
   condicionais e de seleção aos exercícios, quando for possível e
   necessário, e criando um menu para a seleção de qual exercícios será
   executado.

   Compilar com: gcc Exercicio_01.c -o ex01 -lm */

int main(int argc, char *argv[]) {
	int opcao;

	do {
		printf("\n===== LISTA 01 - MENU =====\n");
		printf("1 - Ordem inversa\n");
		printf("2 - Notacao cientifica\n");
		printf("3 - Binario\n");
		printf("4 - Salario com comissao\n");
		printf("5 - Soma, media e produtorio\n");
		printf("6 - Idade em anos, meses e dias\n");
		printf("7 - Volume da esfera\n");
		printf("8 - Distancia entre pontos\n");
		printf("0 - Sair\n");
		printf("Escolha: ");
		scanf("%d", &opcao);

		switch (opcao) {
			case 1: {
				int a, b;
				printf("Digite dois numeros inteiros: ");
				scanf("%d %d", &a, &b);
				printf("Ordem inversa: %d %d\n", b, a);
				break;
			}
			case 2: {
				double valor, a;
				int n = 0;
				printf("Digite um valor positivo: ");
				scanf("%lf", &valor);
				if (valor <= 0) {
					printf("Digite somente valores positivos.\n");
				} else {
					a = valor;
					while (a >= 10) { a = a / 10; n++; }
					while (a < 1)   { a = a * 10; n--; }
					printf("%.4lf x 10^%d\n", a, n);
				}
				break;
			}
			case 3: {
				int n, num, bits[7], qtd = 0, i;
				printf("Digite um numero n (0 a 64): ");
				scanf("%d", &n);
				if (n < 0 || n > 64) {
					printf("Numero invalido!\n");
				} else {
					num = n;
					do {
						bits[qtd] = num % 2;
						num = num / 2;
						qtd++;
					} while (num > 0);
					printf("%d em binario: ", n);
					for (i = qtd - 1; i >= 0; i--) printf("%d", bits[i]);
					printf("\n");
				}
				break;
			}
			case 4: {
				double salario, vendas;
				printf("Digite o salario fixo e o total em vendas: ");
				scanf("%lf %lf", &salario, &vendas);
				if (salario < 0 || vendas < 0) {
					printf("Valores nao podem ser negativos.\n");
				} else {
					printf("TOTAL = R$ %.2lf\n", salario + vendas * 0.15);
				}
				break;
			}
			case 5: {
				int i;
				float valor, soma = 0, produto = 1;
				for (i = 1; i <= 4; i++) {
					printf("Digite o valor %d: ", i);
					scanf("%f", &valor);
					soma = soma + valor;
					produto = produto * valor;
				}
				printf("Soma: %.2f\nMedia: %.2f\nProdutorio: %.2f\n", soma, soma / 4, produto);
				break;
			}
			case 6: {
				int idade;
				printf("Digite a idade em dias: ");
				scanf("%d", &idade);
				if (idade < 0) {
					printf("Idade invalida!\n");
				} else {
					printf("%d ano(s)\n", idade / 365);
					printf("%d mes(es)\n", (idade % 365) / 30);
					printf("%d dia(s)\n", (idade % 365) % 30);
				}
				break;
			}
			case 7: {
				double raio, pi = 3.14159;
				printf("Digite o raio: ");
				scanf("%lf", &raio);
				if (raio < 0) {
					printf("O raio nao pode ser negativo.\n");
				} else {
					printf("VOLUME = %.3lf\n", (4.0 / 3) * pi * raio * raio * raio);
				}
				break;
			}
			case 8: {
				double x1, y1, x2, y2;
				printf("Digite x1, y1, x2 e y2: ");
				scanf("%lf %lf %lf %lf", &x1, &y1, &x2, &y2);
				printf("Distancia = %.4lf\n", sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)));
				break;
			}
			case 0:
				printf("Saindo...\n");
				break;
			default:
				printf("Opcao invalida!\n");
		}
	} while (opcao != 0);

	return 0;
}
